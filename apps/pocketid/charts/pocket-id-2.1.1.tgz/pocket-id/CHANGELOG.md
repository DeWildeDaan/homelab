# Changelog

## [2.1.1](https://github.com/anza-labs/charts/compare/pocket-id-2.1.0...pocket-id-v2.1.1) (2026-04-28)


### Miscellaneous Chores

* **deps:** update ghcr.io/pocket-id/pocket-id docker tag to v2.6.2 ([#391](https://github.com/anza-labs/charts/issues/391)) ([8df3df1](https://github.com/anza-labs/charts/commit/8df3df187243fdfdef5ce32b856be9f2a1c9a15a))

## [2.1.0](https://github.com/anza-labs/charts/compare/pocket-id-2.0.3...pocket-id-v2.1.0) (2026-04-13)


### Features

* **pocket-id:** add hostPath support for persistence ([#385](https://github.com/anza-labs/charts/issues/385)) ([0725e2e](https://github.com/anza-labs/charts/commit/0725e2ec9279fad14f8f47093e8fbc33bbd0f83c))
* **pocket-id:** add trust proxy configuration options ([#383](https://github.com/anza-labs/charts/issues/383)) ([9a36e9d](https://github.com/anza-labs/charts/commit/9a36e9d63e2db325c80583b6243a6e5513609a64))

## [2.0.3](https://github.com/anza-labs/charts/compare/pocket-id-2.0.2...pocket-id-v2.0.3) (2026-04-10)


### Miscellaneous Chores

* **deps:** update docker.io/litestream/litestream docker tag to v0.5.11 ([#378](https://github.com/anza-labs/charts/issues/378)) ([cfdf92d](https://github.com/anza-labs/charts/commit/cfdf92dbe2e7f1e6587ade8bc5e038507a4cdf6c))

## [2.0.2](https://github.com/anza-labs/charts/compare/pocket-id-2.0.1...pocket-id-v2.0.2) (2026-04-07)


### Miscellaneous Chores

* **deps:** update docker.io/litestream/litestream docker tag to v0.5.10 ([#358](https://github.com/anza-labs/charts/issues/358)) ([c0880b9](https://github.com/anza-labs/charts/commit/c0880b9ecc734a0d81830e9dce2b1b7a03b3174a))

## [2.0.1](https://github.com/anza-labs/charts/compare/pocket-id-2.0.0...pocket-id-v2.0.1) (2026-04-07)


### Miscellaneous Chores

* **deps:** update ghcr.io/pocket-id/pocket-id docker tag to v2.5.0 ([#363](https://github.com/anza-labs/charts/issues/363)) ([240c284](https://github.com/anza-labs/charts/commit/240c284d4f4526d4441a124fe1c44be66ed2fa1d))

## [2.0.0](https://github.com/anza-labs/charts/compare/pocket-id-1.7.6...pocket-id-v2.0.0) (2026-03-18)


### ⚠ BREAKING CHANGES

* add note to PocketID chart about v2 migration

### Features

* add note to PocketID chart about v2 migration ([50f0a90](https://github.com/anza-labs/charts/commit/50f0a903e0be81479cfa5f830a07d2869548f1c8))
* **pocket-id:** implement basic v2 chart ([#350](https://github.com/anza-labs/charts/issues/350)) ([bb34d3f](https://github.com/anza-labs/charts/commit/bb34d3f7eccbe50917fbf4cf80b3f02fa4a8882e))

## [1.7.6](https://github.com/anza-labs/charts/compare/pocket-id-1.7.5...pocket-id-v1.7.6) (2026-02-24)


### Miscellaneous Chores

* **deps:** update docker.io/litestream/litestream docker tag to v0.5.9 ([#338](https://github.com/anza-labs/charts/issues/338)) ([1b0152d](https://github.com/anza-labs/charts/commit/1b0152d87a7f6b9a4ce2414fbbedc745cb5416eb))

## [1.7.5](https://github.com/anza-labs/charts/compare/pocket-id-1.7.4...pocket-id-v1.7.5) (2026-02-14)


### Miscellaneous Chores

* **deps:** update docker.io/litestream/litestream docker tag to v0.5.8 ([#328](https://github.com/anza-labs/charts/issues/328)) ([c4305ed](https://github.com/anza-labs/charts/commit/c4305ed6a41b2e80d0a3cab4bbaf0b6837d90b7b))

## [1.7.4](https://github.com/anza-labs/charts/compare/pocket-id-1.7.3...pocket-id-v1.7.4) (2026-01-26)


### Miscellaneous Chores

* **deps:** update docker.io/litestream/litestream docker tag to v0.5.6 ([#315](https://github.com/anza-labs/charts/issues/315)) ([92c5ba0](https://github.com/anza-labs/charts/commit/92c5ba09a700cff6a160a9c5523e5f7c0c5bdde1))

## [1.7.3](https://github.com/anza-labs/charts/compare/pocket-id-1.7.2...pocket-id-v1.7.3) (2026-01-06)


### Miscellaneous Chores

* **deps:** update docker.io/litestream/litestream docker tag to v0.5.5 ([#293](https://github.com/anza-labs/charts/issues/293)) ([b3f4b51](https://github.com/anza-labs/charts/commit/b3f4b510de822e41dcd9886fab206fb5442fc45b))
* **deps:** update ghcr.io/pocket-id/pocket-id docker tag to v1.16.0 ([#287](https://github.com/anza-labs/charts/issues/287)) ([3b4d260](https://github.com/anza-labs/charts/commit/3b4d260cff4da2e7ee57f18fbe00c315a00ca884))

## [1.7.2](https://github.com/anza-labs/charts/compare/pocket-id-1.7.1...pocket-id-v1.7.2) (2025-11-12)


### Miscellaneous Chores

* **deps:** update ghcr.io/pocket-id/pocket-id docker tag to v1.15.0 ([#272](https://github.com/anza-labs/charts/issues/272)) ([8e0f7d4](https://github.com/anza-labs/charts/commit/8e0f7d4f48721b47ae619abf3f9794101c610ba8))

## [1.7.1](https://github.com/anza-labs/charts/compare/pocket-id-1.7.0...pocket-id-v1.7.1) (2025-10-30)


### Miscellaneous Chores

* **deps:** update ghcr.io/pocket-id/pocket-id docker tag to v1.14.0 ([#261](https://github.com/anza-labs/charts/issues/261)) ([07111a9](https://github.com/anza-labs/charts/commit/07111a9ef2148474f7c280c22bd015140a62cc97))
* **deps:** update ghcr.io/pocket-id/pocket-id docker tag to v1.14.2 ([#265](https://github.com/anza-labs/charts/issues/265)) ([2b2e0fc](https://github.com/anza-labs/charts/commit/2b2e0fc775bb4846386418b9a08be984461be5d9))

## [1.7.0](https://github.com/anza-labs/charts/compare/pocket-id-1.6.1...pocket-id-v1.7.0) (2025-10-22)


### Features

* **pocket-id:** set only selector labels on volumes ([#257](https://github.com/anza-labs/charts/issues/257)) ([734a8e0](https://github.com/anza-labs/charts/commit/734a8e08905772670014a816c46e887ed152a68c))

## [1.6.1](https://github.com/anza-labs/charts/compare/pocket-id-1.6.0...pocket-id-v1.6.1) (2025-10-16)


### Miscellaneous Chores

* **deps:** update docker.io/litestream/litestream docker tag to v0.5.2 ([#248](https://github.com/anza-labs/charts/issues/248)) ([cbc9255](https://github.com/anza-labs/charts/commit/cbc9255bd1492d62666509a4320534779bde1225))

## [1.6.0](https://github.com/anza-labs/charts/compare/pocket-id-1.5.6...pocket-id-v1.6.0) (2025-10-09)


### Features

* bump pyoci ([8a3203e](https://github.com/anza-labs/charts/commit/8a3203eb4218baac0f8e03511d587a8facdf6293))


### Miscellaneous Chores

* **deps:** update ghcr.io/pocket-id/pocket-id docker tag to v1.13.1 ([#249](https://github.com/anza-labs/charts/issues/249)) ([2d850e8](https://github.com/anza-labs/charts/commit/2d850e828d006777a9c020b20afbee75458212e2))

## [1.5.6](https://github.com/anza-labs/charts/compare/pocket-id-1.5.5...pocket-id-v1.5.6) (2025-09-19)


### Miscellaneous Chores

* **deps:** update ghcr.io/pocket-id/pocket-id docker tag to v1.11.1 ([#239](https://github.com/anza-labs/charts/issues/239)) ([a2a2135](https://github.com/anza-labs/charts/commit/a2a2135b65aa1dd18b593542f718428fc03e3930))

## [1.5.5](https://github.com/anza-labs/charts/compare/pocket-id-1.5.4...pocket-id-v1.5.5) (2025-08-28)


### Miscellaneous Chores

* **deps:** update ghcr.io/pocket-id/pocket-id docker tag to v1.10.0 ([#218](https://github.com/anza-labs/charts/issues/218)) ([e45cb2a](https://github.com/anza-labs/charts/commit/e45cb2aba31fbf3013503921d623271a40e6a15c))

## [1.5.4](https://github.com/anza-labs/charts/compare/pocket-id-1.5.3...pocket-id-v1.5.4) (2025-08-25)


### Miscellaneous Chores

* **deps:** update ghcr.io/pocket-id/pocket-id docker tag to v1.9.1 ([#212](https://github.com/anza-labs/charts/issues/212)) ([0256288](https://github.com/anza-labs/charts/commit/02562887f3b732d48678c2deef7ba39d66efa460))

## [1.5.3](https://github.com/anza-labs/charts/compare/pocket-id-1.5.2...pocket-id-v1.5.3) (2025-08-24)


### Miscellaneous Chores

* **deps:** update ghcr.io/pocket-id/pocket-id docker tag to v1.8.1 ([#210](https://github.com/anza-labs/charts/issues/210)) ([3aa648f](https://github.com/anza-labs/charts/commit/3aa648f93f6a01a9c7d27118c1a7477a19ace719))
* **deps:** update ghcr.io/pocket-id/pocket-id docker tag to v1.9.0 ([#211](https://github.com/anza-labs/charts/issues/211)) ([95f4de0](https://github.com/anza-labs/charts/commit/95f4de0605f590c04361048f1d10dd2edb85d57b))

## [1.5.2](https://github.com/anza-labs/charts/compare/pocket-id-1.5.1...pocket-id-v1.5.2) (2025-08-11)


### Miscellaneous Chores

* **deps:** update ghcr.io/pocket-id/pocket-id docker tag to v1.7.0 ([#200](https://github.com/anza-labs/charts/issues/200)) ([d4a4e01](https://github.com/anza-labs/charts/commit/d4a4e0168e29385448e6e0bd9bcf4f7a37e64072))

## [1.5.1](https://github.com/anza-labs/charts/compare/pocket-id-1.5.0...pocket-id-v1.5.1) (2025-08-04)


### Bug Fixes

* icons formatting ([f6d11b2](https://github.com/anza-labs/charts/commit/f6d11b2f5c4258f8f5d5fb458bfb2a79f7b15e39))


### Miscellaneous Chores

* add logo to charts ([b6225a5](https://github.com/anza-labs/charts/commit/b6225a5bad1be9f597fe5cd22553505af9ad0b18))
* **main:** release lubelogger 1.1.1 ([#191](https://github.com/anza-labs/charts/issues/191)) ([3e72dcc](https://github.com/anza-labs/charts/commit/3e72dccb23a4b1da9011d5c6eed5909f582834f6))

## [1.5.0](https://github.com/anza-labs/charts/compare/pocket-id-1.4.3...pocket-id-v1.5.0) (2025-07-28)


### Features

* **templates:** add more probe configurations ([#189](https://github.com/anza-labs/charts/issues/189)) ([17da6ca](https://github.com/anza-labs/charts/commit/17da6ca71c1a754fdb15d3db40da5a856a5ca93e))

## [1.4.3](https://github.com/anza-labs/charts/compare/pocket-id-1.4.2...pocket-id-v1.4.3) (2025-07-23)


### Miscellaneous Chores

* **deps:** update ghcr.io/pocket-id/pocket-id docker tag to v1.6.4 ([#184](https://github.com/anza-labs/charts/issues/184)) ([b8f688b](https://github.com/anza-labs/charts/commit/b8f688bfaded17fb4382e514ef2832123b922167))

## [1.4.2](https://github.com/anza-labs/charts/compare/pocket-id-1.4.1...pocket-id-v1.4.2) (2025-07-14)


### Miscellaneous Chores

* **deps:** update ghcr.io/pocket-id/pocket-id docker tag to v1.6.2 ([#177](https://github.com/anza-labs/charts/issues/177)) ([ccd4088](https://github.com/anza-labs/charts/commit/ccd40887a2c81139de12a05e165016315c37ec74))

## [1.4.1](https://github.com/anza-labs/charts/compare/pocket-id-1.4.0...pocket-id-v1.4.1) (2025-07-09)


### Miscellaneous Chores

* **deps:** update ghcr.io/pocket-id/pocket-id docker tag to v1.6.1 ([#170](https://github.com/anza-labs/charts/issues/170)) ([08c323f](https://github.com/anza-labs/charts/commit/08c323fd3edf553162c1412efa5fb08762dc6aec))

## [1.4.0](https://github.com/anza-labs/charts/compare/pocket-id-1.3.1...pocket-id-v1.4.0) (2025-07-05)


### Features

* **pocket-id:** allow postgresql as connection string protocol ([#168](https://github.com/anza-labs/charts/issues/168)) ([75c494f](https://github.com/anza-labs/charts/commit/75c494f80fcb224423862a4c8d1af5dae291b873))

## [1.3.1](https://github.com/anza-labs/charts/compare/pocket-id-1.3.0...pocket-id-v1.3.1) (2025-06-30)


### Miscellaneous Chores

* **deps:** update ghcr.io/pocket-id/pocket-id docker tag to v1.5.0 ([#166](https://github.com/anza-labs/charts/issues/166)) ([5fc4a31](https://github.com/anza-labs/charts/commit/5fc4a31d0468dd8ca41bcbb069e5444e942e945a))

## [1.3.0](https://github.com/anza-labs/charts/compare/pocket-id-1.2.0...pocket-id-v1.3.0) (2025-06-25)


### Features

* **pocket-id:** allow host overriding ([bd1eb35](https://github.com/anza-labs/charts/commit/bd1eb35840bef3980752c870420c4c58807af518))

## [1.2.0](https://github.com/anza-labs/charts/compare/pocket-id-1.1.5...pocket-id-v1.2.0) (2025-06-23)


### Features

* **pocket-id:** add local-ipv6 configuration ([#162](https://github.com/anza-labs/charts/issues/162)) ([a6ad7b6](https://github.com/anza-labs/charts/commit/a6ad7b6c902cfd3f79d03e601795bec6ac0b4bc5))
* **pocket-id:** add otel configuration ([#163](https://github.com/anza-labs/charts/issues/163)) ([6ae1358](https://github.com/anza-labs/charts/commit/6ae1358b3b0c52e323043aa69d7dac8127fe9d86))


### Miscellaneous Chores

* **deps:** update ghcr.io/pocket-id/pocket-id docker tag to v1.4.1 ([#161](https://github.com/anza-labs/charts/issues/161)) ([c5efac7](https://github.com/anza-labs/charts/commit/c5efac76469e315263357c34e387722eff3b214e))

## [1.1.5](https://github.com/anza-labs/charts/compare/pocket-id-1.1.4...pocket-id-v1.1.5) (2025-06-18)


### Bug Fixes

* **pocket-id:** mount paths ([#153](https://github.com/anza-labs/charts/issues/153)) ([79e71b2](https://github.com/anza-labs/charts/commit/79e71b2a419d82db5569e2385e08305b6206f8aa))

## [1.1.4](https://github.com/anza-labs/charts/compare/pocket-id-1.1.3...pocket-id-v1.1.4) (2025-06-11)


### Miscellaneous Chores

* **deps:** update ghcr.io/pocket-id/pocket-id docker tag to v1.3.1 ([#143](https://github.com/anza-labs/charts/issues/143)) ([67b8b82](https://github.com/anza-labs/charts/commit/67b8b82eee5de1708c8f492aa747b0a3a1f060ea))

## [1.1.3](https://github.com/anza-labs/charts/compare/pocket-id-1.1.2...pocket-id-v1.1.3) (2025-06-11)


### Miscellaneous Chores

* **deps:** update ghcr.io/pocket-id/pocket-id docker tag to v1.2.0 ([#135](https://github.com/anza-labs/charts/issues/135)) ([195b28f](https://github.com/anza-labs/charts/commit/195b28f891faf8bd925aedb9c102b62a457de543))
* **multi:** generated new value schemas ([5f4642a](https://github.com/anza-labs/charts/commit/5f4642a315a0785f5ce34d72f9680fb02a387204))

## [1.1.2](https://github.com/anza-labs/charts/compare/pocket-id-1.1.1...pocket-id-v1.1.2) (2025-05-28)


### Bug Fixes

* **pocket-id:** invalid db path ([e04f414](https://github.com/anza-labs/charts/commit/e04f414ede36566312b7c13bb8c026277cdad52e))

## [1.1.1](https://github.com/anza-labs/charts/compare/pocket-id-1.1.0...pocket-id-v1.1.1) (2025-05-28)


### Bug Fixes

* **pocket-id:** invalid db path ([e79fa1d](https://github.com/anza-labs/charts/commit/e79fa1dfe5eb6b34a364f9352c7a331e5090da88))

## [1.1.0](https://github.com/anza-labs/charts/compare/pocket-id-1.0.0...pocket-id-v1.1.0) (2025-05-28)


### Features

* **pocket-id:** add analytics control ([#126](https://github.com/anza-labs/charts/issues/126)) ([a413213](https://github.com/anza-labs/charts/commit/a413213399594498a9dc10c678b750b2e2a0d757))

## 1.0.0 (2025-05-27)


### ⚠ BREAKING CHANGES

* **pocket-id:** prepare for v1 pocket-id release ([#124](https://github.com/anza-labs/charts/issues/124))

### Features

* **pocket-id:** prepare for v1 pocket-id release ([#124](https://github.com/anza-labs/charts/issues/124)) ([b400d09](https://github.com/anza-labs/charts/commit/b400d09e66a4d8b07f988bd56f33494ee1fe8ece))


### Bug Fixes

* **pocket-id:** existingClaim functionality and `PUBLIC_UI_CONFIG_DISABLED` value ([#106](https://github.com/anza-labs/charts/issues/106)) ([dba6f57](https://github.com/anza-labs/charts/commit/dba6f5774dbf512f5ee8a5540b2f0530b0111eb7))
* **pocket-id:** one-time access email settings ([#122](https://github.com/anza-labs/charts/issues/122)) ([fc5b0fc](https://github.com/anza-labs/charts/commit/fc5b0fc248cb0b7e6c5601ebfb93a7934d2870bf))
